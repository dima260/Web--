const { createApp, ref } = Vue;

createApp({
    setup() {
        // Реактивные переменные
        const imageCanvas = ref(null);
        const histCanvas = ref(null);
        const imageData = ref(null);
        const imageWidth = ref(0);
        const imageHeight = ref(0);
        const canvasWidth = ref(800);
        const canvasHeight = ref(600);
        const maxHistValue = ref(0);
        const totalPixels = ref(0);
        const guideX = ref(0);
        const guideValue = ref(0);
        const guideIndex = ref(0);
        const histogram = ref(new Array(256).fill(0));
        const isMouseOverHistogram = ref(false);

        // Загрузка изображения
        function loadImage(event) {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    processImage(img);
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }

        // Обработка изображения
        function processImage(img) {
            const ctx = imageCanvas.value.getContext('2d');
            
            // Установка размеров
            imageWidth.value = img.width;
            imageHeight.value = img.height;
            canvasWidth.value = Math.min(img.width, 800);
            canvasHeight.value = Math.min(img.height, 600);
            
            // Отрисовка оригинального изображения
            ctx.drawImage(img, 0, 0, canvasWidth.value, canvasHeight.value);
            
            // Получение данных
            imageData.value = ctx.getImageData(0, 0, canvasWidth.value, canvasHeight.value);
            const data = imageData.value.data;
            
            // Обработка каждого пикселя: RGB -> CMYK -> Инверсия -> RGB
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i] / 255;
                const g = data[i + 1] / 255;
                const b = data[i + 2] / 255;
                
                // RGB -> CMYK
                let c = 1 - r;
                let m = 1 - g;
                let y = 1 - b;
                let k = Math.min(c, m, y);
                
                // Если черный = 1
                if (k === 1) {
                    c = m = y = 0;
                } else {
                    c = (c - k) / (1 - k);
                    m = (m - k) / (1 - k);
                    y = (y - k) / (1 - k);
                }
                
                // Инверсия CMYK
                c = 1 - c;
                m = 1 - m;
                y = 1 - y;
                k = 1 - k;
                
                // CMYK -> RGB
                const r2 = Math.round(255 * (1 - c) * (1 - k));
                const g2 = Math.round(255 * (1 - m) * (1 - k));
                const b2 = Math.round(255 * (1 - y) * (1 - k));
                
                data[i] = r2;
                data[i + 1] = g2;
                data[i + 2] = b2;
                // Альфа-канал не меняем
            }
            
            // Отрисовка инвертированного изображения
            ctx.putImageData(imageData.value, 0, 0);
            
            // Построение гистограммы
            buildHistogram(data);
            drawHistogram();
        }

        // Построение гистограммы суммарных значений CMYK
        function buildHistogram(data) {
            // Сброс гистограммы
            histogram.value = new Array(256).fill(0);
            totalPixels.value = data.length / 4;
            
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i] / 255;
                const g = data[i + 1] / 255;
                const b = data[i + 2] / 255;
                
                // RGB -> CMYK
                let c = 1 - r;
                let m = 1 - g;
                let y = 1 - b;
                let k = Math.min(c, m, y);
                
                if (k === 1) {
                    c = m = y = 0;
                } else {
                    c = (c - k) / (1 - k);
                    m = (m - k) / (1 - k);
                    y = (y - k) / (1 - k);
                }
                
                // Суммарное значение CMYK (усреднение всех каналов)
                const cmykSum = (c + m + y + k) / 4;
                
                // Преобразование в индекс 0-255
                const index = Math.min(255, Math.max(0, Math.floor(cmykSum * 255)));
                histogram.value[index]++;
            }
            
            // Находим максимальное значение для нормализации отображения
            maxHistValue.value = Math.max(...histogram.value);
        }

        // Отрисовка гистограммы
        function drawHistogram() {
            const ctx = histCanvas.value.getContext('2d');
            const width = histCanvas.value.width;
            const height = histCanvas.value.height;
            
            // Очистка холста
            ctx.clearRect(0, 0, width, height);
            
            // Фон
            ctx.fillStyle = '#f8f9fa';
            ctx.fillRect(0, 0, width, height);
            
            // Параметры гистограммы
            const barWidth = width / 256;
            const maxVal = maxHistValue.value || 1; // Защита от деления на 0
            
            // Отрисовка столбцов гистограммы
            for (let i = 0; i < 256; i++) {
                const barHeight = (histogram.value[i] / maxVal) * (height * 0.8);
                const x = i * barWidth;
                const y = height - barHeight - 20; // Отступ снизу
                
                // Градиентная заливка
                const gradient = ctx.createLinearGradient(0, y, 0, height);
                gradient.addColorStop(0, '#3498db');
                gradient.addColorStop(1, '#2c3e50');
                
                ctx.fillStyle = gradient;
                ctx.fillRect(x, y, barWidth - 1, barHeight);
                
                // Обводка столбцов
                ctx.strokeStyle = '#1a5276';
                ctx.lineWidth = 1;
                ctx.strokeRect(x, y, barWidth - 1, barHeight);
            }
            
            // Направляющая линия (вертикальная) - рисуем только если мышь над гистограммой
            if (isMouseOverHistogram.value && guideX.value >= 0 && guideX.value <= width) {
                ctx.strokeStyle = '#e74c3c';
                ctx.lineWidth = 2;
                ctx.setLineDash([5, 3]);
                ctx.beginPath();
                ctx.moveTo(guideX.value, 0);
                ctx.lineTo(guideX.value, height);
                ctx.stroke();
                ctx.setLineDash([]);
                
                // Рисуем небольшой кружок на линии
                ctx.beginPath();
                ctx.arc(guideX.value, 10, 5, 0, 2 * Math.PI);
                ctx.fillStyle = '#e74c3c';
                ctx.fill();
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 1;
                ctx.stroke();
            }
            
            // Текст под гистограммой
            ctx.fillStyle = '#2c3e50';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('0', 10, height - 5);
            ctx.fillText('255', width - 10, height - 5);
            ctx.fillText('Значения CMYK', width / 2, height - 5);
            
            // Заголовок гистограммы
            ctx.font = 'bold 14px Arial';
            ctx.fillStyle = '#2c3e50';
            ctx.textAlign = 'center';
            ctx.fillText('Суммарная гистограмма CMYK', width / 2, 15);
        }

        // Обновление направляющей линии при движении мыши
        function updateGuide(event) {
            const rect = histCanvas.value.getBoundingClientRect();
            const scaleX = histCanvas.value.width / rect.width; // Масштабирование координат
            
            // Вычисляем координату относительно canvas с учетом масштаба
            let x = (event.clientX - rect.left) * scaleX;
            
            // Ограничиваем координаты
            x = Math.max(0, Math.min(histCanvas.value.width, x));
            
            guideX.value = x;
            isMouseOverHistogram.value = true;
            
            // Вычисляем индекс гистограммы
            const index = Math.floor((x / histCanvas.value.width) * 256);
            guideIndex.value = Math.min(255, Math.max(0, index));
            guideValue.value = histogram.value[guideIndex.value] || 0;
            
            drawHistogram();
        }

        // Сброс направляющей линии при уходе мыши
        function resetGuide() {
            isMouseOverHistogram.value = false;
            guideX.value = 0;
            guideValue.value = 0;
            guideIndex.value = 0;
            drawHistogram();
        }

        // Сброс холстов
        function resetCanvas() {
            const ctx1 = imageCanvas.value.getContext('2d');
            const ctx2 = histCanvas.value.getContext('2d');
            
            ctx1.clearRect(0, 0, canvasWidth.value, canvasHeight.value);
            ctx2.clearRect(0, 0, histCanvas.value.width, histCanvas.value.height);
            
            // Сброс переменных
            imageWidth.value = 0;
            imageHeight.value = 0;
            maxHistValue.value = 0;
            totalPixels.value = 0;
            guideX.value = 0;
            guideValue.value = 0;
            guideIndex.value = 0;
            isMouseOverHistogram.value = false;
            histogram.value = new Array(256).fill(0);
        }

        return {
            // Ссылки
            imageCanvas,
            histCanvas,
            
            // Данные
            imageWidth,
            imageHeight,
            canvasWidth,
            canvasHeight,
            maxHistValue,
            totalPixels,
            guideX,
            guideValue,
            guideIndex,
            
            // Методы
            loadImage,
            resetCanvas,
            updateGuide,
            resetGuide
        };
    }
}).mount('#app');